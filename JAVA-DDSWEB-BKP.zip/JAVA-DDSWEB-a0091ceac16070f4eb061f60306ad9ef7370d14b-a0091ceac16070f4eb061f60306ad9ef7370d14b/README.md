# Arquitetura SPA

Para mais informações acesse nosso [Confluence](https://confluence.ci.gsnet.corp/display/ASAPBRA/)
