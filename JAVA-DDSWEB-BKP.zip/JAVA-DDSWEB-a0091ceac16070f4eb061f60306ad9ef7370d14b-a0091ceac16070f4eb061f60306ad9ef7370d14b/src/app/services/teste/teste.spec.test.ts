import { TesteService } from "./teste.service";

describe ('TesteService', () => {
    const component = new TesteService(null, null);
});
