import { ModuloService } from './modulo.service';


describe('ModuloService', () => {
    const component = new ModuloService(null, null, null);

});
