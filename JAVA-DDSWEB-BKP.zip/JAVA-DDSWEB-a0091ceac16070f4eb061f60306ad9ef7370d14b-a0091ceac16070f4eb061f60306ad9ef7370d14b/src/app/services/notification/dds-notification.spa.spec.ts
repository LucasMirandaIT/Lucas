import { DdsNotificationService } from "./dds-notification.service";

describe('DdsNotificationService', () => {
  const component = new DdsNotificationService();
});
