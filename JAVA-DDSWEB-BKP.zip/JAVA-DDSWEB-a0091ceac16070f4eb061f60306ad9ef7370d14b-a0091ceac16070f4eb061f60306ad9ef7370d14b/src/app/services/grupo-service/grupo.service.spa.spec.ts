import { GrupoService } from './grupo.service';

describe ('GrupoService', () => {
    it ('constructor testing', () => {
        const component = new GrupoService (null, null, null, null);
    });
});
