import { Params } from '@angular/router';

export class BreadCrumb {
    titulo: string;
    url: string;
    parametros?: Params;
}
