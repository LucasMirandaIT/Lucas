export class Modulo {

    cdModuloCanal: number;
    dtInclusao: Date;
    cdUsuarioInclusao: string;
    nmModuloCanal: string;
    indModuloCanal: string;

}
