export class DataCreate {

    agencia: string;
    conta: string;
    cpf: string;

}
