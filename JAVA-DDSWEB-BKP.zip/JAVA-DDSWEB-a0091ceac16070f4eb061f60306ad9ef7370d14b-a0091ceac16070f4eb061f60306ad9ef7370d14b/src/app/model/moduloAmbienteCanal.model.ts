export class ModuloAmbienteCanal {

    cdModuloAmbienteCanal: number;
    nmModuloAmbiente: string;
    descURLModulo: string;
    sgModuloambiente: string;
    dtInclusao: Date;
    cdUsuarioInclusao: string;
    dtUltimaAtualizacao: Date;
    cdUsuarioUltimaAtualizacao: string;
}
