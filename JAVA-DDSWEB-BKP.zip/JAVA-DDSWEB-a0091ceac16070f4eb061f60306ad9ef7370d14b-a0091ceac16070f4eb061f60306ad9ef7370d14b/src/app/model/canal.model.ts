export class Canal {

    cdCanal: number;
    nomeCanal: string;
    cdUsuarioInclusao: string;

}
