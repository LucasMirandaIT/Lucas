export class ModulesLog {

    peticao: any;
    idRundek: any;
    dateActual: any;
    orderer: any;
    module: any;
    ambient: any;
    old_status: any;
    new_status: any;
    rundeck_status: any;
    f5_status: any;
    vip: any;

}
