import { RootComponent } from './root.component';

describe('RootComponent', () => {
    const app = new RootComponent();
});
