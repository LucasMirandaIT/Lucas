import { InfoModulesComponent } from './info-modules.component';

describe('InfoModulesComponent', () => {
    const component = new InfoModulesComponent(null, null, null);

    // it ('test variables', () => {
    //     expect(component.grupo).toBe(null);
    // });

});
