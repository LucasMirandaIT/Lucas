import { IbpjAmbientMonitoringConfirmModalComponent } from './ibpj-ambient-monitoring-confirm-modal.component';

describe ('IbpjAmbientMonitoringConfirmModalComponent', () => {
    const component = new IbpjAmbientMonitoringConfirmModalComponent(null, null);

    it ('test variables', () => {
        expect(component.numeroPeticao).toBe(null);
        expect(component.user).toBe(null);
        expect(component.password).toBe(null);
    });

    it ('saved()', () => {
        component.saved(false, false);
        component.saved(true, false);
    });

});
