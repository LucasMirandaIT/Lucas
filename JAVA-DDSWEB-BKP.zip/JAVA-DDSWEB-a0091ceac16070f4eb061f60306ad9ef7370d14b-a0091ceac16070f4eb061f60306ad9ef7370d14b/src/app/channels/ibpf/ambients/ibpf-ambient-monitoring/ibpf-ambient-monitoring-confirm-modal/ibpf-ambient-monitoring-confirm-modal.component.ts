import { Component, Inject, ViewChild } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA, MatDialog } from '@angular/material';
import { NgForm } from '@angular/forms';

@Component({
  selector: 'ibpf-ambient-monitoring-confirm-modal',
  templateUrl: './ibpf-ambient-monitoring-confirm-modal.component.html',
  styleUrls: ['./ibpf-ambient-monitoring-confirm-modal.component.scss']
})
export class IbpfAmbientMonitoringConfirmModalComponent {

  @ViewChild('loginRundek') loginRundek: NgForm;

  numeroPeticao = null;
  user = null;
  password = null;

  constructor(public dialogRef: MatDialogRef<IbpfAmbientMonitoringConfirmModalComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any
  ) { }

  saved (valid, valid2) {
    if (valid === false) {
      return 'invalid Pt';
    } else if (valid2 === false) {
      return 'invalid Rd';
    } else {
      return this.loginRundek;
    }
  }

}
