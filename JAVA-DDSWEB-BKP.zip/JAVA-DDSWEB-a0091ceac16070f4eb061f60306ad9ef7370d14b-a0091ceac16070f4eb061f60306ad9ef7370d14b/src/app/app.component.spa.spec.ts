import { AppComponent } from './app.component';

describe('AppComponent', () => {
    const component = new AppComponent(null, null);
});
