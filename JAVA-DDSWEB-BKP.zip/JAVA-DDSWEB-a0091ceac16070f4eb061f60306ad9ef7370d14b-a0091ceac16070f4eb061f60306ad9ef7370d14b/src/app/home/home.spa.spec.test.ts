import { HomeComponent } from './home.component';
import {ButtonModule} from 'primeng/button';


describe('HomeComponent', () => {
    const app = new HomeComponent();
});
