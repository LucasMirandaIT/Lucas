export class UserAuth {

    logado: boolean;
    user: string;
    permissoes: any;
}
