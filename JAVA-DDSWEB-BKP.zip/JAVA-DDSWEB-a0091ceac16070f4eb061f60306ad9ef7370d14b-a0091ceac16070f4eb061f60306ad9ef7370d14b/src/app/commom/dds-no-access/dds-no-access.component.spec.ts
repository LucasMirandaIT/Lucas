import { Router } from '@angular/router';
import { DdsNoAccessComponent } from './dds-no-access.component';

describe('DdsNoAccessComponent', () => {
  const component = new DdsNoAccessComponent();

});
