import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'dds-no-access',
  templateUrl: './dds-no-access.component.html',
  styleUrls: ['./dds-no-access.component.scss']
})
export class DdsNoAccessComponent {

}
