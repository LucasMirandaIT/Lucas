import { Component } from '@angular/core';
import { DdsStepItemComponent } from './dds-step-item.component';

@Component({
    selector: 'dds-step-navigation',
    templateUrl: './dds-step-navigation.component.html',
    styleUrls: ['./dds-step-navigation.component.scss']
})
export class DdsStepNavigationComponent { }
