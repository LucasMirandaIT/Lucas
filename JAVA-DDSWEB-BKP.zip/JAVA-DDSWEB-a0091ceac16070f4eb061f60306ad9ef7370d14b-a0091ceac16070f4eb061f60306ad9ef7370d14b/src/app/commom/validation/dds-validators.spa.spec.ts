import { DdsValidatorsComponent } from './dds-validators.component';

describe ('DdsValidatorsComponent', () => {
    const component = new DdsValidatorsComponent();
});
