export class Arquivo {

    nome: string;
    local: string;

}
