import "jquery/dist/jquery.min";
import 'hammerjs';