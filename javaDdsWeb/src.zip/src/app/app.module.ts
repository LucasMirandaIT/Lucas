import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { APP_BASE_HREF } from '@angular/common';
import { CommonModule } from '@angular/common';
import { Http } from '@angular/http';
import { TranslateStaticLoader, TranslateLoader, TranslateModule } from 'ng2-translate';

import { MaterializeModule } from "angular2-materialize";

import { JsonConfigModule } from 'angl-spawebbgrl/json-config-module/config.module';
import { HubConnectorModule } from 'angl-spawebbgrl/spa-http-module/hub-connector.module';
import { ErrorHandlingModule } from 'angl-spawebbgrl/error-handling-module';
import { LogModule } from 'angl-spawebbgrl/log';
import { AppComponent } from './app.component';

@NgModule({
  declarations: [
    AppComponent
  ],
  imports: [
    BrowserModule,
    ErrorHandlingModule,
    JsonConfigModule.forRoot(['assets/url.config.json']),
    TranslateModule.forRoot({
      provide: TranslateLoader,
      useFactory: (http: Http) => new TranslateStaticLoader(http, 'assets/translate', '.json'),
      deps: [Http]
    }),
    HubConnectorModule.forRoot('url_hub_sso'),
    LogModule.forRoot('url_log')
  ],
  providers: [{ provide: APP_BASE_HREF, useValue: '/' }],
  bootstrap: [AppComponent]
})
export class AppModule { }
